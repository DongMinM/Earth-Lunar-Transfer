function tof = find_TOF(mu,c,df,s,a)

alpha = 2 * asin( sqrt( s / (2*a) ) );
beta  = 2 * asin( sqrt( (s-c) / (2*a) ) );

% Range of beta
if df > pi
    beta = 2*pi-beta;
end


tof = a^(3/2) * ((alpha - sin(alpha))-(beta-sin(beta))) / sqrt(mu);


end

