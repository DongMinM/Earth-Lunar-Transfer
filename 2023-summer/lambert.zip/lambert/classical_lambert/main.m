clear
addpath("classic_lambert\","minimun_lambert\")

%% Input %%
mu        =   398600;
r1 = [-7100,2000,2000]';
r2 = [8000,-5000,4000]';
TOF_target     =  3000;
a_init         =  10000;


%% Minimum Case %%
[a_min,t_amin] = minimum_lambert( mu , r1, r2 );


%% Classical Case %%
tol = 1e-9; % seconds
[a,errors] = classic_lambert(mu, r1, r2, TOF_target, a_init, a_min, tol);


plot(errors)
title("ERROR")
grid on
grid minor


